function [R] = testMain(M)
  R = cholesky(M);
end
