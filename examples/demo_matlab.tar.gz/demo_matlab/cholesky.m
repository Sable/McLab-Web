function [R] = cholesky(B)
  A = testIdentity(B)
  [m, n] = size(A);
  R = zeros(m, n);
  for i = (1 : m)
    R(i, i) = sqrt((A(i, i) - sum((abs(R((1 : (i - 1)), i)) .^ 2))));
    for j = ((i + 1) : m)
      R(i, j) = ((A(i, j) - sum((conj(R((1 : (i - 1)), i)) .* R((1 : (i - 1)), j)))) / R(i, i));
    end
  end
end
