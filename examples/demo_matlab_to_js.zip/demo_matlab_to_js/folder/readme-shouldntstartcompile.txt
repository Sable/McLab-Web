Hi this is a silly text file.

This is definitely not a valid matlab file and kind analysis should fail on it.

function silly
end
