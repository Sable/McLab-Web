function [R] = testIdentity(M)
  R = M
end
